var BRANDAI_PLUGIN_REF = 'uxpt';
